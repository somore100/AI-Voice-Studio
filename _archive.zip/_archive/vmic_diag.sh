#!/usr/bin/env bash
# Tests the virtual mic from outside the app: plays a tone into it and records it back.
SINK=avs_voice; SRC=avs_voice_mic
python3 - <<'PY'
import wave, math, struct
sr = 44100
with wave.open("/tmp/avs_tone.wav", "w") as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(sr)
    buf = bytearray()
    for i in range(sr * 6):
        v = int(0.5 * 32767 * math.sin(2 * math.pi * 440 * i / sr))
        buf += struct.pack("<hh", v, v)
    w.writeframes(bytes(buf))
PY
echo "== audio server =="
pactl info | grep -E "Server (Name|Version)|Default (Sink|Source)"
mods=()
if ! pactl list short sinks | cut -f2 | grep -qx "$SINK"; then
  mods+=("$(pactl load-module module-null-sink sink_name=$SINK sink_properties=device.description=AI_Voice_Studio_Mic)"); echo "(created sink - the app was not running)"
fi
if ! pactl list short sources | cut -f2 | grep -qx "$SRC"; then
  mods+=("$(pactl load-module module-remap-source master=$SINK.monitor source_name=$SRC source_properties=device.description=AI_Voice_Studio_Mic)"); echo "(created source - the app was not running)"
fi
echo "== virtual devices =="
pactl list short sinks | grep avs; pactl list short sources | grep avs
echo "== virtual mic: state / mute / volume =="
pactl list sources | awk '/Name: avs_voice_mic/{f=1} f&&/State:|Mute:|Volume:|Monitor of|Description:/{print} f&&/^$/{exit}'
echo "== virtual sink: state / mute / volume =="
pactl list sinks | awk '/Name: avs_voice$/{f=1} f&&/State:|Mute:|Volume:|Description:/{print} f&&/^$/{exit}'
echo
echo ">>> NOW: a 6-second tone plays into the virtual mic. Watch Discord's mic meter. <<<"
parec --device=$SRC --rate=44100 --channels=2 --format=s16le --file-format=wav /tmp/avs_rec.wav & RECPID=$!
sleep 0.7
paplay --device=$SINK /tmp/avs_tone.wav; echo "paplay exit code: $?"
sleep 0.5; kill $RECPID 2>/dev/null; wait $RECPID 2>/dev/null
python3 - <<'PY'
import wave, array, math
w = wave.open("/tmp/avs_rec.wav"); d = array.array("h", w.readframes(w.getnframes()))
rms = math.sqrt(sum(x * x for x in d) / max(len(d), 1)) / 32768
print(f"recorded {w.getnframes()/w.getframerate():.1f}s, rms={rms:.3f} -> "
      + ("SIGNAL REACHES THE VIRTUAL MIC" if rms > 0.05 else "SILENT - nothing reached the virtual mic"))
PY
for ((i=${#mods[@]}-1; i>=0; i--)); do pactl unload-module "${mods[i]}" 2>/dev/null; done
