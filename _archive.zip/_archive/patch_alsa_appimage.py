"""AppImage on non-Debian distros (Fedora etc.): the bundled libasound looks
for its plugins (pipewire / pulse) in Debian's /usr/lib/x86_64-linux-gnu path
and logs 'Cannot open shared library libasound_module_pcm_pipewire.so'.

Fix: before ALSA loads, point ALSA_PLUGIN_DIR at the host's plugin folder
(bundled alsa-lib 1.2.11 honours that variable). If no PipeWire/Pulse plugin
exists on the host, the Speech-to-Text panel's hint says what to install.
Only affects packaged Linux builds; source runs are untouched.
Refuses to run twice; writes nothing unless every anchor matches once.
"""
import sys, shutil

SRC = "main.py"
src = open(SRC, encoding="utf-8").read()
if "_ALSA_PLUGIN_MISSING" in src:
    sys.exit("Already applied")

BLOCK = '''import os
import sys

# ── AppImage: find the host's ALSA plugins (pipewire/pulse) ────────────────
_ALSA_PLUGIN_MISSING = False
if sys.platform.startswith("linux") and getattr(sys, "frozen", False) \\
        and not os.environ.get("ALSA_PLUGIN_DIR"):
    _alsa_dirs = ["/usr/lib64/alsa-lib", "/usr/lib/x86_64-linux-gnu/alsa-lib",
                  "/usr/lib/alsa-lib", "/usr/lib/aarch64-linux-gnu/alsa-lib"]
    _alsa_hit = [d for d in _alsa_dirs
                 if os.path.isfile(os.path.join(d, "libasound_module_pcm_pipewire.so"))
                 or os.path.isfile(os.path.join(d, "libasound_module_pcm_pulse.so"))]
    if _alsa_hit:
        os.environ["ALSA_PLUGIN_DIR"] = _alsa_hit[0]
    else:
        _ALSA_PLUGIN_MISSING = True
_MIC_NOTE = "Don't forget to choose the right microphone!"
if _ALSA_PLUGIN_MISSING:
    _MIC_NOTE += ("\\nNo PipeWire/PulseAudio ALSA plugin found - if the mic doesn't "
                  "work, install 'pipewire-alsa' (Fedora: sudo dnf install pipewire-alsa)")
'''

EDITS = [
    ("import os\nimport sys\n", BLOCK),
    ('                text="Don\'t forget to choose the right microphone!", fg=YELLOW))\n',
     '                text=_MIC_NOTE, fg=YELLOW))\n'),
    ('            f, "Don\'t forget to choose the right microphone!",\n',
     '            f, _MIC_NOTE,\n'),
]
for old, _ in EDITS:
    n = src.count(old)
    assert n == 1, f"anchor matched {n} times (need exactly 1):\n{old[:80]}"

shutil.copy2(SRC, "main.py.pre_alsa")
for old, new in EDITS:
    src = src.replace(old, new, 1)
open(SRC, "w", encoding="utf-8").write(src)
print("OK: main.py patched (3 edits). Backup: main.py.pre_alsa")
