"""Uninstall buttons for Whisper, VCTK and XTTS-v2 in Models & Setup.

An 'Uninstall' button appears on a row while its model is installed.
Clicking it lists exactly which folders/files will be deleted (with sizes)
and asks for confirmation first. Vosk languages already have Download and
Uninstall in the 'Manage' picker. Pip packages are not touched.
Refuses to run twice; writes nothing unless every anchor matches once.
"""
import sys, shutil

SRC = "main.py"
src = open(SRC, encoding="utf-8").read()
if "_uninstall_model" in src:
    sys.exit("Already applied")

FUNC = '''import shutil  # uninstall


def _model_paths(key):
    """Existing files/folders that hold model `key`'s data - nothing else."""
    from engines.paths import get_tts_cache_dir
    found = []
    if key == "whisper":
        home = os.path.expanduser("~")
        xdg = os.environ.get("XDG_CACHE_HOME") or os.path.join(home, ".cache")
        found += [os.path.join(WHISPER_MODEL_DIR, "small.pt"),
                  os.path.join(xdg, "whisper", "small.pt"),
                  os.path.join(home, ".cache", "whisper", "small.pt")]
    elif key in ("vctk", "xtts"):
        sub = {"vctk": "vctk", "xtts": "xtts_v2"}[key]
        found.append(os.path.join(_MODELS_BASE, sub))
        cache = get_tts_cache_dir()
        if os.path.isdir(cache):
            found += [os.path.join(cache, d) for d in sorted(os.listdir(cache))
                      if sub in d]
    out, seen = [], set()
    for p in found:
        rp = os.path.realpath(p)
        # safety: never anything shallower than /x/y/z
        if rp in seen or not os.path.exists(rp) or len(rp.split(os.sep)) < 4:
            continue
        seen.add(rp)
        out.append(p)
    return out


def _path_size(p):
    if os.path.isfile(p):
        return os.path.getsize(p)
    total = 0
    for root, _d, files in os.walk(p):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def _uninstall_model(self, key):
    global _whisper_model
    paths = _model_paths(key)
    if not paths:
        messagebox.showinfo("Uninstall", "No files found for this model.")
        return
    lines = [f"{p}  ({_path_size(p) / 1048576:.0f} MB)" for p in paths]
    total = sum(_path_size(p) for p in paths) / 1048576
    if not messagebox.askyesno(
            "Uninstall model",
            "Delete these files?\\n\\n" + "\\n".join(lines) +
            f"\\n\\nTotal: {total:.0f} MB. You can download the model again "
            f"later."):
        return

    def _work():
        failed = []
        for p in paths:
            try:
                if os.path.isdir(p):
                    shutil.rmtree(p)
                else:
                    os.remove(p)
            except Exception as e:
                failed.append(f"{p}: {e}")
        # drop the in-memory copy so the next use reloads (or reports missing)
        try:
            if key == "whisper":
                _whisper_model = None
            else:
                mod = sys.modules.get({"vctk": "engines.coqui_vctk",
                                       "xtts": "engines.coqui_xtts"}[key])
                if mod is not None:
                    mod._instance = None
        except Exception:
            pass
        def _done():
            if failed:
                messagebox.showerror("Uninstall failed", "\\n".join(failed))
            self._check_models()
        self.root.after(0, _done)

    threading.Thread(target=_work, daemon=True).start()


# Patch these methods onto AIApp
AIApp._uninstall_model = _uninstall_model
'''

EDITS = [
    ("    self._model_rows = {}\n",
     "    self._model_rows = {}\n    self._model_unins = {}\n"),
    ("        self._model_rows[key] = (status, btn)\n",
     "        self._model_rows[key] = (status, btn)\n"
     "        if key == \"whisper\" or key in TTS_ENGINES:\n"
     "            self._model_unins[key] = tk.Button(\n"
     "                row, text=\"Uninstall\", bg=SURFACE, fg=RED, relief=\"flat\",\n"
     "                cursor=\"hand2\", padx=8, pady=2, bd=0,\n"
     "                font=(\"Segoe UI\",8,\"bold\"),\n"
     "                command=lambda k=key: self._uninstall_model(k))\n"),
    ("def _set_model_status(self, key, ok, text=None):\n"
     "    status, btn = self._model_rows[key]\n",
     "def _set_model_status(self, key, ok, text=None):\n"
     "    status, btn = self._model_rows[key]\n"
     "    _ub = getattr(self, \"_model_unins\", {}).get(key)\n"
     "    if _ub is not None:\n"
     "        if ok is True:\n"
     "            _ub.pack(side=\"right\", padx=4)\n"
     "        else:\n"
     "            _ub.pack_forget()\n"),
    ("# Patch these methods onto AIApp\n", FUNC),
]
for old, _ in EDITS:
    n = src.count(old)
    assert n == 1, f"anchor matched {n} times (need exactly 1):\n{old[:80]}"
assert "SURFACE" in src and "RED" in src

shutil.copy2(SRC, "main.py.pre_uninstall")
for old, new in EDITS:
    src = src.replace(old, new)
open(SRC, "w", encoding="utf-8").write(src)
print("OK: main.py patched (4 edits). Backup: main.py.pre_uninstall")
