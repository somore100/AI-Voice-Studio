#!/usr/bin/env python3
"""Editing a curve now ticks "Use curves" automatically (it defaulted to off,
so drawn curves were silently ignored). Patches curve_editor.py."""
import shutil, sys
P = "curve_editor.py"
src = open(P, encoding="utf-8").read()
if "_ready = [False]" in src:
    print("Already applied"); sys.exit(0)

def sub(s, old, new):
    assert s.count(old) == 1, f"anchor matched {s.count(old)}x: {old[:50]!r}"
    return s.replace(old, new)

src = sub(src,
"""    def changed():
        k = audio_fx.length_factor(state)
""",
"""    _ready = [False]

    def changed():
        if _ready[0] and not use_var.get():
            use_var.set(True)      # editing a curve means you want it applied
        k = audio_fx.length_factor(state)
""")
src = sub(src, "    changed()\n    return win\n",
               "    changed()\n    _ready[0] = True\n    return win\n")
shutil.copy(P, P + ".pre_autoon")
open(P, "w", encoding="utf-8").write(src)
print("OK - curve_editor.py patched (backup: curve_editor.py.pre_autoon)")
