"""Voice Changer upgrade (STT -> TTS pipeline mode).

 1. Model choices in the Voice Changer panel: 'Hear with' (Same as the
    Speech-to-Text tab / Whisper / Vosk) and 'Speak with' (Same as the
    Text-to-Speech tab / VCTK / XTTS-v2) + a Voice picker. The loop honours
    them (Vosk was never used before; Whisper ignored the language).
    A model that isn't installed is reported up front instead of silently
    downloading in the background.
 2. Real virtual microphone on Linux (PulseAudio / PipeWire via pactl):
    'Send to virtual microphone' creates 'AI_Voice_Studio_Mic'. Choose it as
    the microphone in your call app and the call hears only the changed voice.
 3. 'Playback (hear it yourself)' checkbox: local monitoring on/off,
    independent of the virtual mic.
 4. Mode now defaults to the STT->TTS pipeline ('Pitch only' is still a stub).
Refuses to run twice; writes nothing unless every anchor matches once.
"""
import sys, shutil

SRC = "main.py"
src = open(SRC, encoding="utf-8").read()
if "_vc_resolve" in src:
    sys.exit("Already applied")

UI = '''        self.vc_mode = tk.StringVar(value="TTS pipeline (STT→TTS)")
        ttk.Combobox(pl, textvariable=self.vc_mode, state="readonly",
                     values=["Pitch only", "TTS pipeline (STT→TTS)"],
                     width=24, font=("Segoe UI",9)).pack(side="left", padx=6)

        # Model choices
        r1 = tk.Frame(f, bg=CARD); r1.pack(fill="x", padx=2, pady=3)
        self._label(r1, "Hear with:").pack(side="left")
        self.vc_stt_choice = tk.StringVar(value=_VC_SAME_STT)
        ttk.Combobox(r1, textvariable=self.vc_stt_choice, state="readonly",
                     values=[_VC_SAME_STT, "Whisper", "Vosk"], width=26,
                     font=("Segoe UI",9)).pack(side="left", padx=6)
        self._label(r1, "language: from the Speech-to-Text tab",
                    fg=FG_DIM, font=("Segoe UI",8)).pack(side="left")

        r2 = tk.Frame(f, bg=CARD); r2.pack(fill="x", padx=2, pady=3)
        self._label(r2, "Speak with:").pack(side="left")
        self.vc_tts_choice = tk.StringVar(value=_VC_SAME_TTS)
        ttk.Combobox(r2, textvariable=self.vc_tts_choice, state="readonly",
                     values=[_VC_SAME_TTS, "VCTK (English voices)",
                             "XTTS-v2 (Multilingual)"], width=26,
                     font=("Segoe UI",9)).pack(side="left", padx=6)
        self._label(r2, "Voice:").pack(side="left")
        self.vc_voice_var = tk.StringVar(value="")
        self._vc_voice_map = {}
        self._vc_voice_cb = ttk.Combobox(r2, textvariable=self.vc_voice_var,
                                         state="disabled", values=[], width=22,
                                         font=("Segoe UI",9))
        self._vc_voice_cb.pack(side="left", padx=6)
        self.vc_tts_choice.trace_add("write", lambda *_: self._vc_refresh_voices())

        # Output routing
        r3 = tk.Frame(f, bg=CARD); r3.pack(fill="x", padx=2, pady=3)
        self.vc_vmic = tk.BooleanVar(value=_vmic_available())
        _vm = ttk.Checkbutton(r3, text="Send to virtual microphone",
                              variable=self.vc_vmic)
        _vm.pack(side="left", padx=(0,12))
        if not _vmic_available():
            _vm.state(["disabled"])
        self.vc_playback = tk.BooleanVar(value=True)
        ttk.Checkbutton(r3, text="Playback (hear it yourself)",
                        variable=self.vc_playback).pack(side="left")
        if _vmic_available():
            _hint = ("Call app: choose \\"" + _VMIC_LABEL + "\\" as the microphone "
                     "(keep your real mic selected above). Use headphones with "
                     "Playback on.")
        elif sys.platform.startswith("linux"):
            _hint = ("Virtual mic needs 'pactl' and 'paplay' (package "
                     "pulseaudio-utils). Playback only until installed.")
        else:
            _hint = ("Virtual microphone is Linux-only for now. Playback "
                     "plays on your speakers.")
        self._label(f, _hint, fg=FG_DIM, font=("Segoe UI",8)).pack(
            anchor="w", padx=4)
'''

OLD_MODE = '''        self.vc_mode = tk.StringVar(value="Pitch only")
        ttk.Combobox(pl, textvariable=self.vc_mode, state="readonly",
                     values=["Pitch only", "TTS pipeline (STT→TTS)"],
                     width=24, font=("Segoe UI",9)).pack(side="left", padx=6)
'''

OLD_START = '''            if self._is_xtts() and not self._ensure_engine_tos("xtts"):
                return
        self._vc_running = True
'''
NEW_START = '''            cfg, err = self._vc_resolve()
            if err:
                self._vc_report(err)
                return
            if cfg["vmic"]:
                ok, msg = self._vmic_create()
                if not ok:
                    messagebox.showerror("Virtual microphone", msg)
                    return
            self._vc_cfg = cfg
        self._vc_running = True
'''

OLD_HEAD = '''            engine = self.stt_engine.get() if hasattr(self, 'stt_engine') else "Whisper (recommended)"
            lang_disp = self.stt_lang_var.get() if hasattr(self, 'stt_lang_var') else "English"
            mic_idx = self._resolve_mic_index()
'''
NEW_HEAD = '''            cfg = self._vc_cfg
            mic_idx = self._resolve_mic_index()
            _vosk = _vrec_cls = None
            if cfg["stt"] == "vosk":
                try:
                    from vosk import KaldiRecognizer as _vrec_cls
                    self.root.after(0, lambda: self._vc_status.config(
                        text=f"Loading Vosk ({cfg['vlang']})...", fg=YELLOW))
                    _vosk = get_vosk_model(cfg["vlang"])
                except Exception as e:
                    self._vc_running = False
                    self.root.after(0, lambda err=str(e): self._vc_status.config(
                        text=f"Error: {err[:60]}", fg=RED))
                    return
'''

OLD_STT = '''                    raw = np.frombuffer(
                        audio.get_raw_data(convert_rate=16000, convert_width=2),
                        dtype=np.int16).astype(np.float32) / 32768.0
                    model = get_whisper_model()
                    result = model.transcribe(raw, fp16=False)
                    text = result["text"].strip()
'''
NEW_STT = '''                    pcm = audio.get_raw_data(convert_rate=16000, convert_width=2)
                    if cfg["stt"] == "vosk":
                        rec = _vrec_cls(_vosk, 16000)
                        for _i in range(0, len(pcm), 8000):
                            rec.AcceptWaveform(pcm[_i:_i + 8000])
                        text = json.loads(rec.FinalResult()).get("text", "").strip()
                    else:
                        raw = np.frombuffer(pcm, dtype=np.int16).astype(np.float32) / 32768.0
                        kw = {"language": cfg["wlang"]} if cfg.get("wlang") else {}
                        text = get_whisper_model().transcribe(
                            raw, fp16=False, **kw)["text"].strip()
'''

OLD_TTS = '''                        sid = self.get_selected_speaker_id() if not self._is_xtts() else None
                        t0 = self._log_tts_job(text, sid, "VC speak")
                        if sid:
                            TTS_ENGINES["vctk"].synthesize(text, sid, tmp.name)
                        else:
                            lang = LANG_XTTS.get(self.xtts_lang_var.get(), "en")
                            TTS_ENGINES["xtts"].synthesize(
                                text, self._xtts_voice_arg(), tmp.name, lang)
'''
NEW_TTS = '''                        t0 = time.time()
                        print(f"[AVS] VC speak: stt={cfg['stt']} tts={cfg['tts']} "
                              f"voice={cfg['voice']} chars={len(text)}")
                        if cfg["tts"] == "vctk":
                            TTS_ENGINES["vctk"].synthesize(text, cfg["voice"], tmp.name)
                        else:
                            TTS_ENGINES["xtts"].synthesize(
                                text, cfg["voice"], tmp.name, cfg["xtts_lang"])
'''

OLD_PLAY = '''                        pygame.mixer.music.load(tmp.name)
                        pygame.mixer.music.play()
                        while pygame.mixer.music.get_busy() and self._vc_running:
                            time.sleep(0.1)
'''
NEW_PLAY = '''                        self._vc_play(tmp.name, cfg)
                        try:
                            os.remove(tmp.name)
                        except OSError:
                            pass
'''

OLD_CLOSE = '''        self.root.destroy()

    def _request_mic_permission(self):
'''
NEW_CLOSE = '''        self._vmic_destroy()
        self.root.destroy()

    def _request_mic_permission(self):
'''

FUNCS = '''import subprocess  # voice changer: virtual mic

_VC_SAME_STT = "Same as Speech-to-Text tab"
_VC_SAME_TTS = "Same as Text-to-Speech tab"
_VMIC_SINK   = "avs_voice"
_VMIC_SOURCE = "avs_voice_mic"
_VMIC_LABEL  = "AI_Voice_Studio_Mic"


def _ext_env():
    """Environment for launching host tools (pactl/paplay) from a packaged
    build: drop the bundled-library paths so they load the host's libraries."""
    env = os.environ.copy()
    if "LD_LIBRARY_PATH_ORIG" in env:
        env["LD_LIBRARY_PATH"] = env["LD_LIBRARY_PATH_ORIG"]
    bad = [p for p in (getattr(sys, "_MEIPASS", None), os.environ.get("APPDIR")) if p]
    parts = [p for p in env.get("LD_LIBRARY_PATH", "").split(":")
             if p and not any(p.startswith(b) for b in bad)]
    if parts:
        env["LD_LIBRARY_PATH"] = ":".join(parts)
    else:
        env.pop("LD_LIBRARY_PATH", None)
    return env


def _vmic_tools():
    """(pactl, player) if a virtual mic can be used here, else None."""
    if not sys.platform.startswith("linux"):
        return None
    pactl = shutil.which("pactl")
    player = shutil.which("paplay") or shutil.which("pw-play")
    return (pactl, player) if pactl and player else None


def _vmic_available():
    return _vmic_tools() is not None


def _vmic_cmd(args, timeout=8):
    return subprocess.run(args, capture_output=True, text=True,
                          timeout=timeout, env=_ext_env())


def _vmic_names(pactl, kind):
    out = _vmic_cmd([pactl, "list", "short", kind]).stdout
    return {ln.split("\\t")[1] for ln in out.splitlines() if "\\t" in ln}


def _vmic_create(self):
    """Create the virtual mic (a null sink plus a source that appears as a
    real microphone). Returns (ok, message)."""
    tools = _vmic_tools()
    if not tools:
        return False, ("The virtual microphone needs 'pactl' and 'paplay' "
                       "(package pulseaudio-utils; Fedora: sudo dnf install "
                       "pulseaudio-utils, Debian/Ubuntu: sudo apt install "
                       "pulseaudio-utils).")
    pactl = tools[0]
    made = []
    try:
        if _VMIC_SINK not in _vmic_names(pactl, "sinks"):
            r = _vmic_cmd([pactl, "load-module", "module-null-sink",
                           f"sink_name={_VMIC_SINK}",
                           f"sink_properties=device.description={_VMIC_LABEL}"])
            if r.returncode != 0 or not r.stdout.strip().isdigit():
                return False, ("Could not create the virtual sink: "
                               + (r.stderr.strip() or r.stdout.strip() or "unknown error"))
            made.append(r.stdout.strip())
        if _VMIC_SOURCE not in _vmic_names(pactl, "sources"):
            r = _vmic_cmd([pactl, "load-module", "module-remap-source",
                           f"master={_VMIC_SINK}.monitor",
                           f"source_name={_VMIC_SOURCE}",
                           f"source_properties=device.description={_VMIC_LABEL}"])
            if r.returncode != 0 or not r.stdout.strip().isdigit():
                for mid in made:
                    _vmic_cmd([pactl, "unload-module", mid])
                return False, ("Could not create the virtual microphone: "
                               + (r.stderr.strip() or r.stdout.strip() or "unknown error"))
            made.append(r.stdout.strip())
    except Exception as e:
        return False, f"Virtual microphone setup failed: {e}"
    self._vmic_modules = list(reversed(made)) + getattr(self, "_vmic_modules", [])
    return True, "ready"


def _vmic_destroy(self):
    tools = _vmic_tools()
    if not tools:
        return
    for mid in getattr(self, "_vmic_modules", []):
        try:
            _vmic_cmd([tools[0], "unload-module", mid])
        except Exception:
            pass
    self._vmic_modules = []


def _vmic_play(self, path):
    player = _vmic_tools()[1]
    if os.path.basename(player) == "pw-play":
        cmd = [player, f"--target={_VMIC_SINK}", path]
    else:
        cmd = [player, f"--device={_VMIC_SINK}", path]
    return subprocess.Popen(cmd, env=_ext_env(),
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def _vc_refresh_voices(self):
    choice = self.vc_tts_choice.get()
    self._vc_voice_map = {}
    if choice.startswith("VCTK"):
        for n in sorted(SPEAKER_MAP):
            self._vc_voice_map[f"{n} ({SPEAKER_MAP[n][0]})"] = SPEAKER_MAP[n][0]
        names = list(self._vc_voice_map)
    elif choice.startswith("XTTS"):
        from engines.coqui_xtts import PRESET_SPEAKERS
        names = list(PRESET_SPEAKERS) + ["Cloned voice (from Text-to-Speech tab)"]
    else:
        names = []
    self._vc_voice_cb.config(values=names, state="readonly" if names else "disabled")
    self.vc_voice_var.set(names[0] if names else "")


def _vc_resolve(self):
    """Snapshot the Voice Changer's choices on the main thread.
    Returns (cfg, None) or (None, (kind, payload)) for _vc_report()."""
    stt = self.vc_stt_choice.get()
    if stt == _VC_SAME_STT:
        stt = self.stt_engine.get() if hasattr(self, "stt_engine") else "Whisper"
    lang_disp = self.stt_lang_var.get() if hasattr(self, "stt_lang_var") else "English"
    cfg = {"stt": "vosk" if stt.startswith("Vosk") else "whisper",
           "wlang": LANG_WHISPER.get(lang_disp), "vlang": LANG_VOSK.get(lang_disp),
           "playback": bool(self.vc_playback.get()),
           "vmic": bool(self.vc_vmic.get()) and _vmic_available()}
    if not cfg["playback"] and not cfg["vmic"]:
        return None, ("msg", "Turn on Playback or Send to virtual microphone - "
                             "otherwise the converted voice goes nowhere.")
    if cfg["stt"] == "vosk":
        if not VOSK_AVAILABLE:
            return None, ("msg", "Vosk is not installed.")
        if not cfg["vlang"] or not _vosk_model_ok(
                os.path.join(VOSK_MODEL_DIR, cfg["vlang"])):
            return None, ("vosk-missing", cfg["vlang"] or "?")
    elif not WHISPER_AVAILABLE:
        return None, ("msg", "Whisper is not installed.")

    tts = self.vc_tts_choice.get()
    if tts == _VC_SAME_TTS:
        key = "xtts" if self._is_xtts() else "vctk"
        if key == "vctk":
            voice = self.get_selected_speaker_id()
        else:
            voice = self._xtts_voice_arg()
    elif tts.startswith("VCTK"):
        key = "vctk"
        voice = self._vc_voice_map.get(self.vc_voice_var.get())
    else:
        key = "xtts"
        v = self.vc_voice_var.get()
        if v.startswith("Cloned"):
            if not getattr(self, "xtts_clone_path", None):
                return None, ("msg", "No cloned voice is set. Pick a clip with "
                                     "'Clone Voice from File...' in the "
                                     "Text-to-Speech tab, or choose a preset.")
            voice = self._xtts_voice_arg()
        else:
            voice = v
    if not voice:
        return None, ("msg", "Pick a voice (here, or in the Text-to-Speech tab).")
    cfg["tts"], cfg["voice"] = key, voice
    lang = LANG_XTTS.get(self.xtts_lang_var.get(), "en") if hasattr(self, "xtts_lang_var") else "en"
    cfg["xtts_lang"] = lang if lang in XTTS_SUPPORTED else "en"
    try:
        if not TTS_ENGINES[key].is_installed():
            return None, ("tts-missing", TTS_ENGINES[key].display_name)
    except Exception:
        pass
    if key == "xtts" and not self._ensure_engine_tos("xtts"):
        return None, ("cancel", "")
    return cfg, None


def _vc_report(self, err):
    kind, payload = err
    if kind == "vosk-missing":
        self._vosk_missing_prompt(payload, f"No Vosk model for '{payload}'.")
    elif kind == "tts-missing":
        messagebox.showerror("Voice Changer",
                             f"{payload} isn't installed. Download it first in "
                             f"Models & Setup.")
    elif kind == "msg":
        messagebox.showerror("Voice Changer", payload)


def _vc_play(self, path, cfg):
    procs = []
    if cfg["vmic"]:
        try:
            procs.append(self._vmic_play(path))
        except Exception as e:
            print(f"[AVS] virtual mic playback failed: {e}")
    if cfg["playback"]:
        pygame.mixer.music.load(path)
        pygame.mixer.music.play()
    try:
        while self._vc_running:
            busy = any(p.poll() is None for p in procs) or (
                cfg["playback"] and pygame.mixer.music.get_busy())
            if not busy:
                break
            time.sleep(0.05)
    finally:
        for p in procs:
            if p.poll() is None:
                p.terminate()
        if cfg["playback"]:
            pygame.mixer.music.stop()
            try:
                pygame.mixer.music.unload()
            except Exception:
                pass


# Patch these methods onto AIApp
AIApp._vmic_create = _vmic_create
AIApp._vmic_destroy = _vmic_destroy
AIApp._vmic_play = _vmic_play
AIApp._vc_refresh_voices = _vc_refresh_voices
AIApp._vc_resolve = _vc_resolve
AIApp._vc_report = _vc_report
AIApp._vc_play = _vc_play
'''

EDITS = [
    (OLD_MODE, UI), (OLD_START, NEW_START), (OLD_HEAD, NEW_HEAD),
    (OLD_STT, NEW_STT), (OLD_TTS, NEW_TTS), (OLD_PLAY, NEW_PLAY),
    (OLD_CLOSE, NEW_CLOSE), ("# Patch these methods onto AIApp\n", FUNCS),
]
for old, _ in EDITS:
    n = src.count(old)
    assert n == 1, f"anchor matched {n} times (need exactly 1):\n{old[:90]}"
for need in ("_vosk_model_ok", "_vosk_missing_prompt", "VOSK_MODEL_DIR",
             "LANG_WHISPER", "XTTS_SUPPORTED", "_ensure_engine_tos"):
    assert need in src, f"required name missing from main.py: {need}"

shutil.copy2(SRC, "main.py.pre_vc")
for old, new in EDITS:
    src = src.replace(old, new, 1)
open(SRC, "w", encoding="utf-8").write(src)
print("OK: main.py patched (8 edits). Backup: main.py.pre_vc")
