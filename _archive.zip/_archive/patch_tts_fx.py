"""Wire speed + pitch into TTS (Preview, Save) and the voice changer's
STT->TTS pipeline, via audio_fx.py (must sit next to main.py).

 - TTS panel: Speed slider now works; new Pitch slider (semitones).
 - Voice Changer panel: its Speed/Pitch sliders now apply in pipeline mode.
Refuses to run twice; writes nothing unless every anchor matches once.
"""
import sys, os, shutil

SRC = "main.py"
src = open(SRC, encoding="utf-8").read()
if "_apply_tts_fx" in src:
    sys.exit("Already applied")
if not os.path.isfile("audio_fx.py"):
    sys.exit("audio_fx.py not found next to main.py - copy it here first")

UI = '''        self._btn(spd, "Reset", lambda: self.tts_speed.set(1.0),
                  color=SURFACE, padx=6).pack(side="left", padx=4)

        # Pitch slider (post-process, works with every engine)
        pch = tk.Frame(f, bg=CARD); pch.pack(fill="x", padx=2, pady=4)
        self._label(pch, "Pitch:").pack(side="left")
        self.tts_pitch = tk.DoubleVar(value=0.0)
        ttk.Scale(pch, from_=-12.0, to=12.0, orient="horizontal",
                  variable=self.tts_pitch, length=200).pack(side="left", padx=6)
        self._pitch_label = tk.Label(pch, text="+0.0", bg=CARD, fg=CYAN,
                                     font=("Segoe UI",9,"bold"), width=5)
        self._pitch_label.pack(side="left")
        self.tts_pitch.trace_add("write", lambda *_: self._pitch_label.config(
            text=f"{self.tts_pitch.get():+.1f}"))
        self._btn(pch, "Reset", lambda: self.tts_pitch.set(0.0),
                  color=SURFACE, padx=6).pack(side="left", padx=4)
        self._fx_track(self.tts_speed, "speed")
        self._fx_track(self.tts_pitch, "pitch")
'''

FUNCS = '''def _fx_track(self, var, key):
    """Mirror a Tk variable into a plain dict so worker threads can read
    it safely (calling .get() on a Tk variable off the main thread isn't)."""
    vals = self.__dict__.setdefault(
        "_fx_vals",
        {"speed": 1.0, "pitch": 0.0, "vc_speed": 1.0, "vc_pitch": 0.0})
    def _upd(*_):
        try:
            vals[key] = float(var.get())
        except Exception:
            pass
    var.trace_add("write", _upd)
    _upd()


def _apply_tts_fx(self, path, speed_key, pitch_key):
    vals = getattr(self, "_fx_vals", {})
    sp = vals.get(speed_key, 1.0)
    pt = vals.get(pitch_key, 0.0)
    try:
        import audio_fx
        if audio_fx.apply_fx(path, sp, pt):
            print(f"[AVS] FX applied: speed={sp:.2f} pitch={pt:+.1f}st")
    except Exception:
        print("[AVS] FX skipped (audio unchanged):")
        traceback.print_exc()


# Patch these methods onto AIApp
AIApp._fx_track = _fx_track
AIApp._apply_tts_fx = _apply_tts_fx
'''

EDITS = [
    ('        self._btn(spd, "Reset", lambda: self.tts_speed.set(1.0),\n'
     '                  color=SURFACE, padx=6).pack(side="left", padx=4)\n', UI),
    ('        self.vc_speed.trace_add("write", lambda *_: self._vc_speed_lbl.config(\n'
     '            text=f"{self.vc_speed.get():.1f}x"))\n',
     '        self.vc_speed.trace_add("write", lambda *_: self._vc_speed_lbl.config(\n'
     '            text=f"{self.vc_speed.get():.1f}x"))\n'
     '        self._fx_track(self.vc_speed, "vc_speed")\n'
     '        self._fx_track(self.vc_pitch, "vc_pitch")\n'),
    ('            print(f"[AVS] Preview ready in {time.time()-t0:.1f}s -> {tmp.name}")\n',
     '            self._apply_tts_fx(tmp.name, "speed", "pitch")\n'
     '            print(f"[AVS] Preview ready in {time.time()-t0:.1f}s -> {tmp.name}")\n'),
    ('            print(f"[AVS] Saved in {time.time()-t0:.1f}s -> {out}")\n',
     '            self._apply_tts_fx(out, "speed", "pitch")\n'
     '            print(f"[AVS] Saved in {time.time()-t0:.1f}s -> {out}")\n'),
    ('                        print(f"[AVS] VC speak ready in {time.time()-t0:.1f}s")\n',
     '                        self._apply_tts_fx(tmp.name, "vc_speed", "vc_pitch")\n'
     '                        print(f"[AVS] VC speak ready in {time.time()-t0:.1f}s")\n'),
    ("# Patch these methods onto AIApp\n", FUNCS),
]
for old, _ in EDITS:
    n = src.count(old)
    assert n == 1, f"anchor matched {n} times (need exactly 1):\n{old[:90]}"

shutil.copy2(SRC, "main.py.pre_fx")
for old, new in EDITS:
    src = src.replace(old, new)
open(SRC, "w", encoding="utf-8").write(src)
print("OK: main.py patched (6 edits). Backup: main.py.pre_fx")
