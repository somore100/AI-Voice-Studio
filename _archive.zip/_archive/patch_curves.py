"""Speed & pitch curve editor for the Text-to-Speech panel.

Adds an 'Edit speed / pitch curves...' button and a 'Use curves' checkbox
under the Pitch slider. The curves reshape the finished speech on Preview and
Save (they combine with the Speed/Pitch sliders). Needs audio_fx.py (updated
version) and curve_editor.py next to main.py; patch_tts_fx.py applied first.
Refuses to run twice; writes nothing unless every anchor matches once.
"""
import sys, os, shutil

SRC = "main.py"
src = open(SRC, encoding="utf-8").read()
if "_open_curve_editor" in src:
    sys.exit("Already applied")
for need in ("audio_fx.py", "curve_editor.py"):
    if not os.path.isfile(need):
        sys.exit(f"{need} not found next to main.py - copy it here first")
if "_apply_tts_fx" not in src:
    sys.exit("Apply patch_tts_fx.py first")

UI = '''        self._fx_track(self.tts_pitch, "pitch")

        # Speed / pitch curves (CapCut-style editor)
        self._curves = {"on": False, "smooth": True,
                        "speed": [(0.0, 1.0), (1.0, 1.0)],
                        "pitch": [(0.0, 0.0), (1.0, 0.0)]}
        self.tts_curves_on = tk.BooleanVar(value=False)
        self.tts_curves_on.trace_add(
            "write", lambda *_: self._curves.__setitem__(
                "on", bool(self.tts_curves_on.get())))
        cvr = tk.Frame(f, bg=CARD); cvr.pack(fill="x", padx=2, pady=4)
        self._label(cvr, "Curves:").pack(side="left")
        self._btn(cvr, "Edit speed / pitch curves...", self._open_curve_editor,
                  color=SURFACE, padx=8).pack(side="left", padx=6)
        ttk.Checkbutton(cvr, text="Use curves",
                        variable=self.tts_curves_on).pack(side="left")
'''

APPLY_OLD = "        if audio_fx.apply_fx(path, sp, pt):\n"
APPLY_NEW = '''        cv = None
        if speed_key == "speed":
            c = getattr(self, "_curves", None)
            if c and c.get("on"):
                cv = {"smooth": c["smooth"], "speed": list(c["speed"]),
                      "pitch": list(c["pitch"])}
        if audio_fx.apply_fx(path, sp, pt, curves=cv):
'''
PRINT_OLD = '            print(f"[AVS] FX applied: speed={sp:.2f} pitch={pt:+.1f}st")\n'
PRINT_NEW = ('            print(f"[AVS] FX applied: speed={sp:.2f} pitch={pt:+.1f}st "\n'
             '                  f"curves={\'on\' if cv else \'off\'}")\n')

FUNCS = '''def _open_curve_editor(self):
    from curve_editor import open_editor
    colors = {"bg": BG, "card": CARD, "fg": FG, "dim": FG_DIM,
              "border": BORDER, "accent": CYAN, "surface": SURFACE}
    open_editor(self.root, self._curves, self.tts_curves_on, colors)


# Patch these methods onto AIApp
AIApp._open_curve_editor = _open_curve_editor
'''

EDITS = [
    ('        self._fx_track(self.tts_pitch, "pitch")\n', UI),
    (APPLY_OLD, APPLY_NEW),
    (PRINT_OLD, PRINT_NEW),
    ("# Patch these methods onto AIApp\n", FUNCS),
]
for old, _ in EDITS:
    n = src.count(old)
    assert n == 1, f"anchor matched {n} times (need exactly 1):\n{old[:90]}"

shutil.copy2(SRC, "main.py.pre_curves")
for old, new in EDITS:
    src = src.replace(old, new, 1)
open(SRC, "w", encoding="utf-8").write(src)
print("OK: main.py patched (4 edits). Backup: main.py.pre_curves")
