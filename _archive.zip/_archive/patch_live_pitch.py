"""Live 'Pitch only' voice changer (Linux: PulseAudio / PipeWire).

Mic -> pitch shift (live_pitch.py, must sit next to main.py) -> virtual
microphone and/or your headphones. The Pitch slider works while it runs.
No speech recognition or TTS involved, so it is fast (~150 ms end to end).
The Speed slider is not used in this mode.
Needs the same setup as the virtual mic, plus 'pacat' (pulseaudio-utils).
Refuses to run twice; writes nothing unless every anchor matches once.
"""
import sys, os, shutil

SRC = "main.py"
src = open(SRC, encoding="utf-8").read()
if "_vc_live_loop" in src:
    sys.exit("Already applied")
if not os.path.isfile("live_pitch.py"):
    sys.exit("live_pitch.py not found next to main.py - copy it here first")
if "_vc_resolve" not in src:
    sys.exit("Apply patch_voice_changer.py first")

OLD_START = '''            self._vc_cfg = cfg
        self._vc_running = True
'''
NEW_START = '''            self._vc_cfg = cfg
        else:
            if not self._ensure_mic_access():
                return
            cfg, err = self._vc_resolve_live()
            if err:
                self._vc_report(err)
                return
            if cfg["vmic"]:
                ok, msg = self._vmic_create()
                if not ok:
                    messagebox.showerror("Virtual microphone", msg)
                    return
            self._vc_cfg = cfg
        self._vc_running = True
'''

OLD_STUB = '''        else:
            # Pitch only mode - shift pitch of mic input
            self.root.after(0, lambda: self._vc_status.config(
                text="Pitch mode: play audio to hear effect", fg=YELLOW))
            time.sleep(1)
            self.root.after(0, lambda: self._vc_status.config(
                text="Tip: Use TTS pipeline mode for real-time voice changing", fg=FG_DIM))
            self._vc_running = False
'''
NEW_STUB = '''        else:
            self._vc_live_loop()
'''

FUNCS = '''def _vc_resolve_live(self):
    """Checks for the live pitch mode (main thread). (cfg, None) or (None, err)."""
    cfg = {"playback": bool(self.vc_playback.get()),
           "vmic": bool(self.vc_vmic.get()) and _vmic_available()}
    if not sys.platform.startswith("linux") or not shutil.which("pacat"):
        return None, ("msg", "Live Pitch only mode needs Linux with PulseAudio/"
                             "PipeWire and the 'pacat' tool (package "
                             "pulseaudio-utils). Use the STT->TTS mode instead.")
    if not cfg["playback"] and not cfg["vmic"]:
        return None, ("msg", "Turn on Playback or Send to virtual microphone - "
                             "otherwise the converted voice goes nowhere.")
    try:
        import live_pitch  # noqa: F401
    except Exception as e:
        return None, ("msg", f"live_pitch.py could not be loaded: {e}")
    if cfg["playback"] and not getattr(self, "_vc_live_ok", False):
        if not messagebox.askyesno(
                "Playback needs headphones",
                "Live Playback sends your changed voice to your speakers. "
                "Without headphones the microphone hears it again and you "
                "get a loud feedback howl.\\n\\nContinue with Playback on?"):
            return None, ("cancel", "")
        self._vc_live_ok = True
    return cfg, None


def _vc_live_loop(self):
    import numpy as np
    from live_pitch import PitchShifter
    cfg = self._vc_cfg
    pacat = shutil.which("pacat")
    outs = []

    def _open_out(rate, device):
        cmd = [pacat, "--playback", f"--rate={rate}", "--channels=1",
               "--format=s16le", "--latency-msec=40",
               "--client-name=AI Voice Studio", "--stream-name=Voice Changer"]
        if device:
            cmd.append(f"--device={device}")
        p = subprocess.Popen(cmd, stdin=subprocess.PIPE, env=_ext_env(),
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            import fcntl
            fcntl.fcntl(p.stdin.fileno(), 1031, 4096)   # F_SETPIPE_SZ: small pipe
        except Exception:                               # keeps the delay bounded
            pass
        return p

    try:
        with self._open_mic(self._resolve_mic_index()) as source:
            rate = int(source.SAMPLE_RATE)
            chunk = source.CHUNK
            shifter = PitchShifter(rate)
            if cfg["vmic"]:
                outs.append(_open_out(rate, _VMIC_SINK))
            if cfg["playback"]:
                outs.append(_open_out(rate, None))
            print(f"[AVS] live pitch: rate={rate} chunk={chunk} vmic={cfg['vmic']} "
                  f"playback={cfg['playback']} latency~{shifter.latency_samples / rate * 1000:.0f}ms",
                  flush=True)
            shown = None
            while self._vc_running:
                data = source.stream.read(chunk)
                x = np.frombuffer(data, dtype=np.int16).astype(np.float32) / 32768.0
                semis = float(getattr(self, "_fx_vals", {}).get("vc_pitch", 0.0))
                y = shifter.process(x, 2.0 ** (semis / 12.0))
                a = np.abs(y)                          # soft limiter above 0.8
                y = np.where(a > 0.8, np.sign(y) * (0.8 + 0.2 * np.tanh((a - 0.8) / 0.2)), y)
                pcm = (y * 32767.0).astype(np.int16).tobytes()
                for p in outs:
                    if p.poll() is not None:
                        raise RuntimeError("Audio output stopped (pacat exited)")
                    p.stdin.write(pcm)
                    p.stdin.flush()
                if shown is None or abs(semis - shown) >= 0.1:
                    shown = semis
                    self.root.after(0, lambda s=semis: self._vc_status.config(
                        text=f"Live pitch: {s:+.1f} semitones", fg=GREEN))
    except Exception as e:
        print(f"[AVS] live pitch error: {e!r}", flush=True)
        if self._vc_running:
            self.root.after(0, lambda err=str(e): self._vc_status.config(
                text=f"Error: {err[:60]}", fg=RED))
    finally:
        for p in outs:
            try:
                p.stdin.close()
            except Exception:
                pass
            try:
                p.terminate()
            except Exception:
                pass
        self._vc_running = False


# Patch these methods onto AIApp
AIApp._vc_resolve_live = _vc_resolve_live
AIApp._vc_live_loop = _vc_live_loop
'''

EDITS = [(OLD_START, NEW_START), (OLD_STUB, NEW_STUB),
         ("# Patch these methods onto AIApp\n", FUNCS)]
for old, _ in EDITS:
    n = src.count(old)
    assert n == 1, f"anchor matched {n} times (need exactly 1):\n{old[:90]}"

shutil.copy2(SRC, "main.py.pre_live")
for old, new in EDITS:
    src = src.replace(old, new, 1)
open(SRC, "w", encoding="utf-8").write(src)
print("OK: main.py patched (3 edits). Backup: main.py.pre_live")
