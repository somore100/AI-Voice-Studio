#!/usr/bin/env bash
# Shows who is capturing the virtual mic (and with what mute/volume), then
# plays real speech (or a speech-like buzz) into it. Run with Discord's mic test open.
SINK=avs_voice; SRC=avs_voice_mic
echo "== virtual mic index =="
pactl list short sources | grep -w "$SRC"
echo
echo "== every program capturing audio right now (source = which mic it is connected to) =="
pactl list short source-outputs
echo
pactl list source-outputs | awk 'BEGIN{RS="";ORS="\n\n"} /Source Output #/' \
  | grep -E "Source Output|Source:|Corked|Mute:|Volume:|application.name|application.process.binary|media.name|Sample Specification|Channel Map"
echo
SPEECH=/usr/share/sounds/alsa/Front_Center.wav
if [ ! -f "$SPEECH" ]; then
  echo "(no $SPEECH here - using a generated speech-like buzz instead)"
  python3 - <<'PY'
import wave, math, struct
sr = 44100
with wave.open("/tmp/avs_speechlike.wav", "w") as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(sr)
    buf = bytearray()
    for i in range(sr * 5):
        t = i / sr
        env = 0.5 + 0.5 * math.sin(2 * math.pi * 3.5 * t)
        f0 = 110 + 25 * math.sin(2 * math.pi * 0.7 * t)
        v = sum(math.sin(2 * math.pi * f0 * k * t) / k for k in range(1, 12))
        s = int(0.22 * 32767 * env * v / 2.5)
        buf += struct.pack("<hh", s, s)
    w.writeframes(bytes(buf))
PY
  SPEECH=/tmp/avs_speechlike.wav
fi
echo ">>> NOW: playing real speech into the virtual mic 3 times. Watch Discord's meter. <<<"
for n in 1 2 3; do paplay --device=$SINK "$SPEECH"; echo "play $n exit code: $?"; sleep 1; done
